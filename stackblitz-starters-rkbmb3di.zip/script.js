const movements = [
  {
    name: "Literatura Antigua",
    period: "Hasta S. V a.C.",
    color: "#e67e22",
    desc: "Desarrollada en Grecia y Roma. Se enfocaba en mitos, héroes y dioses de tradición oral y teatral.",
    authors: [
      { 
        name: "Homero", 
        bio: "Poeta griego a quien se le atribuye la autoría de las principales epopeyas griegas.",
        works: ["La Odisea", "La Ilíada"], 
        mainWork: "La Odisea",
        mainWorkDesc: "Relata el épico viaje de regreso de Odiseo a su hogar en Ítaca tras la Guerra de Troya."
      },
      { 
        name: "Sófocles", 
        bio: "Dramaturgo griego, uno de los grandes maestros de la tragedia clásica.",
        works: ["Edipo Rey", "Antígona"], 
        mainWork: "Edipo Rey",
        mainWorkDesc: "Tragedia sobre el destino e inevitable cumplimiento de una profecía personal."
      },
      { 
        name: "Virgilio", 
        bio: "Poeta romano considerado uno de los más grandes de la antigüedad latina.",
        works: ["La Eneida"], 
        mainWork: "La Eneida",
        mainWorkDesc: "Poema épico que narra los viajes de Eneas para fundar el origen del pueblo romano."
      }
    ]
  },
  {
    name: "Literatura Medieval",
    period: "Siglo V – XV",
    color: "#8e44ad",
    desc: "Relacionada con la religión, vida caballeresca y relatos heroicos de transmisión oral.",
    authors: [
      { 
        name: "Dante Alighieri", 
        bio: "Poeta italiano crucial en la transición del pensamiento medieval al renacentista.",
        works: ["La Divina Comedia"], 
        mainWork: "La Divina Comedia",
        mainWorkDesc: "Alegoría sobre el viaje del alma a través del Infierno, el Purgatorio y el Paraíso."
      },
      { 
        name: "Gonzalo de Berceo", 
        bio: "Primer poeta castellano de nombre conocido y máximo exponente del Mester de Clerecía.",
        works: ["Milagros de Nuestra Señora"], 
        mainWork: "Milagros de Nuestra Señora",
        mainWorkDesc: "Colección de relatos ejemplares sobre la intervención y milagros de la Virgen."
      },
      { 
        name: "Geoffrey Chaucer", 
        bio: "Considerado el padre de la literatura inglesa moderna.",
        works: ["Los cuentos de Canterbury"], 
        mainWork: "Los cuentos de Canterbury",
        mainWorkDesc: "Historias narradas por un grupo de peregrinos que viajan hacia la catedral de Canterbury."
      }
    ]
  },
  {
    name: "Renacimiento",
    period: "Siglo XV – XVI",
    color: "#27ae60",
    desc: "Basado en el humanismo y la cultura grecolatina. Busca el equilibrio y la valoración del ser humano.",
    authors: [
      { 
        name: "William Shakespeare", 
        bio: "Dramaturgo y poeta inglés, ampliamente reconocido como el escritor más importante en lengua inglesa.",
        works: ["Romeo y Julieta", "Hamlet"], 
        mainWork: "Romeo y Julieta",
        mainWorkDesc: "Tragedia de amor prohibido entre dos jóvenes pertenecientes a familias enemistadas."
      },
      { 
        name: "Miguel de Cervantes", 
        bio: "Novelista y dramaturgo español, figura cumbre de la literatura universal.",
        works: ["Don Quijote de la Mancha"], 
        mainWork: "Don Quijote de la Mancha",
        mainWorkDesc: "Sátira de los libros de caballerías que explora la dualidad entre idealismo y realidad."
      },
      { 
        name: "Garcilaso de la Vega", 
        bio: "Poeta e hidalgo español que introdujo las formas métricas italianas en la poesía lírica.",
        works: ["Églogas"], 
        mainWork: "Églogas",
        mainWorkDesc: "Poemas bucólicos donde pastores expresan desamores en entornos idílicos."
      }
    ]
  },
  {
    name: "Barroco",
    period: "Siglo XVII",
    color: "#c0392b",
    desc: "Lenguaje complejo con contrastes de luz y sombra. Explora el amor, la muerte y el tiempo.",
    authors: [
      { 
        name: "Luis de Góngora", 
        bio: "Poeta español máximo exponente de la corriente literaria conocida como culteranismo.",
        works: ["Soledades"], 
        mainWork: "Soledades",
        mainWorkDesc: "Poema inacabado caracterizado por una intensa ornamentación estética y metáforas complejas."
      },
      { 
        name: "Francisco de Quevedo", 
        bio: "Escritor español del Siglo de Oro, maestro del conceptismo lírico y satírico.",
        works: ["El Buscón"], 
        mainWork: "El Buscón",
        mainWorkDesc: "Novela picaresca que muestra con humor negro las aventuras y picardías del joven Pablos."
      },
      { 
        name: "Sor Juana Inés de la Cruz", 
        bio: "Erudita y religiosa novohispana, máxima figura de las letras hispanoamericanas del siglo XVII.",
        works: ["Primero Sueño"], 
        mainWork: "Primero Sueño",
        mainWorkDesc: "Poema filosófico que describe el viaje del alma humana en búsqueda del conocimiento universal."
      }
    ]
  },
  {
    name: "Neoclasicismo",
    period: "Siglo XVIII",
    color: "#2980b9",
    desc: "Guiado por la razón y la moral. Rechaza la decoración excesiva del Barroco.",
    authors: [
      { 
        name: "Leandro Fdz. de Moratín", 
        bio: "Dramaturgo y poeta ilustrado español, principal autor teatral del siglo XVIII.",
        works: ["El sí de las niñas"], 
        mainWork: "El sí de las niñas",
        mainWorkDesc: "Comedia que critica los matrimonios arreglados por conveniencia e impuesta por la autoridad paterna."
      },
      { 
        name: "Gaspar M. de Jovellanos", 
        bio: "Escritor, jurista y político ilustrado clave en el pensamiento de la Ilustración española.",
        works: ["El delincuente honrado"], 
        mainWork: "El delincuente honrado",
        mainWorkDesc: "Drama reformista que reflexiona sobre la justicia y el rigor excesivo de las leyes del momento."
      }
    ]
  },
  {
    name: "Romanticismo",
    period: "Siglo XIX",
    color: "#d35400",
    desc: "Eleva el sentimiento, la libertad individual y la imaginación por encima de la razón.",
    authors: [
      { 
        name: "Gustavo Adolfo Bécquer", 
        bio: "Poeta y narrador español precursor de la poesía lírica moderna.",
        works: ["Rimas y Leyendas"], 
        mainWork: "Rimas y Leyendas",
        mainWorkDesc: "Colección de poemas íntimos sobre el amor y prosas líricas centradas en el misterio y lo sobrenatural."
      },
      { 
        name: "José de Espronceda", 
        bio: "Poeta representante del romanticismo exaltado y rebelde en España.",
        works: ["El estudiante de Salamanca"], 
        mainWork: "El estudiante de Salamanca",
        mainWorkDesc: "Poema narrativo enfocado en la figura legendaria de Don Félix y su carácter desafiante."
      },
      { 
        name: "Lord Byron", 
        bio: "Poeta británico considerado una de las figuras más influyentes del romanticismo europeo.",
        works: ["Don Juan"], 
        mainWork: "Don Juan",
        mainWorkDesc: "Poema épico e irónico que invierte la leyenda del seductor convirtiéndolo en víctima de las circunstancias."
      }
    ]
  },
  {
    name: "Realismo",
    period: "Siglo XIX",
    color: "#16a085",
    desc: "Describe la realidad cotidiana sin idealizar, analizando las desigualdades sociales.",
    authors: [
      { 
        name: "Benito Pérez Galdós", 
        bio: "Novelista español, referente indispensable de la narrativa realista de la época.",
        works: ["Fortunata y Jacinta"], 
        mainWork: "Fortunata y Jacinta",
        mainWorkDesc: "Visión panorámica de la sociedad madrileña trazada a través de las vidas de dos mujeres."
      },
      { 
        name: "Leopoldo Alas 'Clarín'", 
        bio: "Crítico y narrador español, autor de obras maestras del naturalismo y realismo en España.",
        works: ["La Regenta"], 
        mainWork: "La Regenta",
        mainWorkDesc: "Análisis psicológico profundo sobre la opresión social y moral en una ciudad de provincias."
      }
    ]
  },
  {
    name: "Modernismo y Vanguardismo",
    period: "Fin S. XIX – S. XX",
    color: "#6c5ce7",
    desc: "Búsqueda de belleza absoluta y ruptura con las formas tradicionales del arte.",
    authors: [
      { 
        name: "Rubén Darío", 
        bio: "Poeta nicaragüense denominado el 'Príncipe de las letras castellanas' y padre del modernismo.",
        works: ["Azul..."], 
        mainWork: "Azul...",
        mainWorkDesc: "Libro de cuentos y poemas que dio inicio oficial al movimiento modernista en Hispanoamérica."
      },
      { 
        name: "Federico García Lorca", 
        bio: "Poeta y dramaturgo español perteneciente a la insigne Generación del 27.",
        works: ["Romancero Gitano"], 
        mainWork: "Romancero Gitano",
        mainWorkDesc: "Obra lírica que fusiona la tradición popular gitana con metáforas poéticas vanguardistas."
      },
      { 
        name: "Pablo Neruda", 
        bio: "Poeta chileno galardonado con el Premio Nobel de Literatura.",
        works: ["Veinte poemas de amor..."], 
        mainWork: "Veinte poemas de amor y una canción desesperada",
        mainWorkDesc: "Poemario juvenil centrado en la melancolía, el amor, la pasión y la pérdida."
      }
    ]
  },
  {
    name: "Literatura Contemporánea",
    period: "Siglos XX – XXI",
    color: "#00b894",
    desc: "Refleja la diversidad cultural, identidad, memoria y cambios de la vida moderna.",
    authors: [
      { 
        name: "Gabriel García Márquez", 
        bio: "Escritor colombiano, referente máximo del realismo mágico y Premio Nobel de Literatura.",
        works: ["Cien años de soledad"], 
        mainWork: "Cien años de soledad",
        mainWorkDesc: "Crónica generacional de la familia Buendía en el pueblo ficticio de Macondo."
      },
      { 
        name: "Laura Esquivel", 
        bio: "Escritora y política mexicana, reconocida internacionalmente por su estilo narrativo.",
        works: ["Como agua para chocolate"], 
        mainWork: "Como agua para chocolate",
        mainWorkDesc: "Novela que combina el realismo mágico con el arte gastronómico y las tradiciones familiares."
      },
      { 
        name: "Salman Rushdie", 
        bio: "Escritor británico-indio famoso por combinar ficción histórica con realismo mágico.",
        works: ["Hijos de la medianoche"], 
        mainWork: "Hijos de la medianoche",
        mainWorkDesc: "Relato de la transición de la India del colonialismo británico a la independencia."
      }
    ]
  }
];

const timelineEl = document.getElementById('timeline');
const modalEl = document.getElementById('author-modal');
const modalBody = document.getElementById('modal-body');
const closeModalBtn = document.getElementById('close-modal');

// Renderizar tarjetas coloridas
movements.forEach((m) => {
  const card = document.createElement('div');
  card.className = 'epoch-card';
  card.style.borderLeftColor = m.color;

  const authorsList = document.createElement('div');
  authorsList.className = 'authors-list';

  m.authors.forEach(a => {
    const btn = document.createElement('button');
    btn.className = 'author-btn';
    btn.textContent = a.name;
    btn.style.color = m.color;
    btn.style.backgroundColor = `${m.color}15`;

    btn.addEventListener('click', () => openModal(a, m.color));
    authorsList.appendChild(btn);
  });

  card.innerHTML = `
    <div class="epoch-title">
      <h2 style="color: ${m.color}">${m.name}</h2>
      <span style="color: ${m.color}">${m.period}</span>
    </div>
    <p class="epoch-desc">${m.desc}</p>
    <div class="authors-label">Autores principales</div>
  `;

  card.appendChild(authorsList);
  timelineEl.appendChild(card);
});

// Función para abrir la ventana modal
function openModal(author, color) {
  modalBody.innerHTML = `
    <h3 style="color: ${color}; margin-bottom: 6px;">${author.name}</h3>
    <p style="font-style: italic; color: #666; font-size: 0.9rem; margin-bottom: 12px;">${author.bio}</p>
    <p style="margin-bottom: 12px;"><strong>Obras destacadas:</strong><br>${author.works.join(', ')}</p>
    <div class="highlight-box" style="border-left-color: ${color}">
      <strong style="color: ${color}">Obra más representativa: ${author.mainWork}</strong>
      <span style="font-size: 0.88rem; color: #444; display: block; margin-top: 4px;">${author.mainWorkDesc}</span>
    </div>
  `;
  modalEl.classList.remove('hidden');
}

// Escuchadores de eventos para cerrar la ventana modal
closeModalBtn.addEventListener('click', () => modalEl.classList.add('hidden'));
window.addEventListener('click', (e) => { 
  if (e.target === modalEl) modalEl.classList.add('hidden'); 
});